# Kavram - PyQt5 Dijital Devre Simülatörü

Ana kart üzerinde dijital devre tasarlayıp çalıştırabileceğin masaüstü uygulaması.
Dokunmatik ekranlarda da çalışır.

## Kurulum ve çalıştırma

```bash
pip install -r requirements.txt
python main.py
```

Python 3.8 veya üzeri gerekir.

## Dosyalar

| Dosya | İçerik |
|---|---|
| `main.py` | Pencere, tuval, paletler, paneller, dokunmatik ve fare olayları |
| `visuals.py` | Görsel katman: ana kart, parça görünümleri, pinler (sadece çizim) |
| `circuit.py` | Simülatör motoru (arayüzden bağımsız): netler, mantık, bellekler, kaydetme, örnekler |
| `requirements.txt` | PyQt5 bağımlılığı |

## Parçalar

| Grup | Parçalar |
|---|---|
| Temel | Güç kaynağı, toprak, anahtar, **dokunmatik**, **ekran**, LED, saat |
| Mantık kapıları | NOT, AND, OR, NAND, NOR, XOR |
| İşlemci | **İşlemci çekirdeği** (1 bitlik toplayıcı: S = toplam, C = elde) |
| Bellek | D flip-flop, **RAM** (uçucu), **SSD** (kalıcı) |

## Dokunmatik kullanım

- **Tek parmak:** Parçayı seç ve sürükle, pinden pine kablo çek, anahtarı çevir.
- **İki parmak:** Kıstırarak yakınlaştır ve kaydır.
- **Dokunmatik parça:** Basılı tuttuğun sürece sinyal 1 olur. Bırakınca 0.
- **Ekran:** Bağlı sinyali büyük "1" veya "0" olarak gösterir.

## Fare kullanımı

- **Parça ekle:** Sol paletteki bileşeni tuvale sürükle veya çift tıkla.
- **Kablo çek:** Bir pinin üstünden başla, başka bir pine sürükle ve bırak.
- **Anahtarı aç/kapat:** Anahtara tıkla.
- **Yakınlaştır:** Fare tekerleği, araç çubuğundaki + / − veya "Sığdır".
- **Sil:** Parçayı seçip `Delete` tuşuna bas, ya da Sil aracıyla tıkla.
- **Geri al / İleri al:** `Ctrl+Z` / `Ctrl+Y`.
- **Simülasyon:** `Boşluk` tuşu veya Başlat. "Bir Darbe" ile tek adım ilerlersin.

## Simülasyon nasıl çalışır?

- Güç kaynağı voltajı 2.5 V üzerindeyse 1, altındaysa 0 üretir.
- Kapılar girişlerine göre çıkışını hesaplar.
- İşlemci çekirdeği iki girişi toplar: S toplamı, C eldeyi verir.
- Saat her darbede değişir. RAM, D flip-flop ve SSD yükselen kenarda veriyi alır (WE açıksa).
- **RAM ve D flip-flop uçucudur:** Sıfırlayınca silinir.
- **SSD kalıcıdır:** Sıfırlamadan etkilenmez.
- Bir bağlantıya aynı anda 0 ve 1 basan iki çıkış bağlanırsa kısa devre uyarısı verilir.

## Yeni parça eklemek

1. `circuit.py` içindeki `COMPONENTS` sözlüğüne yeni bir girdi ekle (ad, boyut, pinler, grup).
2. Mantık gerekiyorsa `Circuit._combinational` (kombinasyonel) veya `Circuit.tick` (bellek) içine kural ekle.
3. Görünümü `visuals.py` içinde `_DRAWERS` sözlüğüne bir çizim fonksiyonu ekleyerek tanımla.
4. Palette otomatik görünür, çünkü `GROUPS` grubuna göre listelenir.

## Sıradaki adımlar

1. Transistör modelini ekle (NPN/PNP/NMOS/PMOS) ve anahtar olarak kullan.
2. Direnç ve kapasitör; RC zamanlama grafiği.
3. Çok bitli register ve ALU (toplama, çıkarma).
4. Komut seti ve küçük bir assembler (LOAD, ADD, STORE, JMP).
5. Program Counter ve 7 segment gösterge.
